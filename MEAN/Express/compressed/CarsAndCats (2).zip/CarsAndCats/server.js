var express = require("express");
var app = express();

app.use(express.static(__dirname + "/static"))
console.log(__dirname);

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/cars', function(request, response) {
    console.log(request);
    response.render('cars');
})
app.get('/cats', function(request, response) {
    console.log(request);
    response.render('cats');
})
app.get('/new/car', function(request, response) {
    console.log(request);
    response.render('form');
})

app.listen(8000, function() {
    console.log("Listening on port 8000");
})