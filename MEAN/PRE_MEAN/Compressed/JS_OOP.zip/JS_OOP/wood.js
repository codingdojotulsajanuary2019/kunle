var Christopher = {character: "Christopher Robin"};
var Pooh = {character: "Winnie the Pooh"};
var Piglet = {character: "Piglet"};
var Owl = {character: "Owl"};
var Rabbit = {character: "Rabbit"};
var Bees = {character: "Bees"};
var Gopher = {character: "Gopher"};
var Tigger = {character: "Tigger"};
var Kanga = {character: "Kanga"};
var Eeyore = {character: "Eeyore"};
var Heffalumps = {character: "Heffalumps"};

Christopher.East = Rabbit;
Christopher.North = Kanga;
Christopher.South = Pooh;
Christopher.West = Owl;

Pooh.East = Bees;
Pooh.West = Piglet;
Pooh.North = Christopher;
Pooh.South = Tigger;

Piglet.North = Owl;
Piglet.East = Pooh;

Owl.East = Christopher;

Rabbit.East = Gopher;
Rabbit.South = Bees;
Rabbit.West = Christopher;

Bees.North = Rabbit;
Bees.West = Pooh;

Gopher.West = Rabbit;

Tigger.North = Pooh;

Kanga.North = Eeyore;
Kanga.South = Christopher;

Eeyore.East = Heffalumps;
Eeyore.South = Kanga;

Heffalumps.West = Eeyore;

var player = {
    location: Pooh
}

function move(str){
    console.log(player.location);
    console.log(player.location[str]);
    if(player.location[str]){
        player.location = player.location[str];
        console.log(player.location);
        name = player.location.character;
        console.log("You are now at ",name,"'s house");
    }
    else{
        console.log("You may not go there");
    }
}