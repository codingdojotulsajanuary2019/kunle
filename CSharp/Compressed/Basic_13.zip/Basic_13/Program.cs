﻿using System;

namespace Basic_13
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] first = Basic13.OddArray();
            Console.WriteLine(first);
        }
    }
}
