using System;

namespace Users.Models
{
    public class MyModel
    {
       
    }
}