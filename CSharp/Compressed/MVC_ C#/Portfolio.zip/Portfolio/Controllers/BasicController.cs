using Microsoft.AspNetCore.Mvc;
namespace Portfolio
{
    public class BasicController : Controller
    {
        [HttpGet("")]
        public string Index()
        {
            return "This is my index!";
        }

        [HttpGet("{name}")]
        public string Projects(string name)
        {
            return $"This is my {name}";
        }

        [HttpGet("contact")]
        public string Contacts()
        {
            return "This is my Contact!";
        }
    }
}