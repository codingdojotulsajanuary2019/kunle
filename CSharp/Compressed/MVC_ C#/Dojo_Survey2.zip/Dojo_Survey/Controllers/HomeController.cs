using System;
using Dojo_Survey.Models;
using Microsoft.AspNetCore.Mvc;

namespace Dojo_Survey
{
    public class HomeController : Controller
    {
        [HttpGet("")]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost("survey")]
        public IActionResult Result(Survey result)
        {
            return View(result);
        }
    }
}