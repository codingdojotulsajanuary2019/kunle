using System;

namespace Passcode.Models
{
    public class MyModel
    {
       
    }
}