using System;

namespace Dojodachi.Models
{
    public class MyModel
    {
        public string Action {get; set;}
        public int Happiness {get; set;}
        public int Fullness {get; set;}

        public int Energy {get; set;}

        public int Meal {get; set;}
    }
}