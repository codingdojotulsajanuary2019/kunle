# Authorization
Authorization is the process of only allowing resources to be accessed by users
permitted to access them. For example, one user shouldn't be able to change
another user's password.

In this challenge you will need to discover and fix the authorization flaws
present in this web app.
