$(document).ready(function(){
    $('#ShowTitle').keyup(function(){
        var data = $('#AddShow').serialize()
        $.ajax({
            method: "POST",
            url: "/ShowTitle",
            data: data
        })
        .done(function(res){
            $('#part_msg').html(res)
        })
    })
})

                