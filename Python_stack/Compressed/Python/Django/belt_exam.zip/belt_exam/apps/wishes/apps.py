from django.apps import AppConfig


class WishesConfig(AppConfig):
    name = 'wishes'
