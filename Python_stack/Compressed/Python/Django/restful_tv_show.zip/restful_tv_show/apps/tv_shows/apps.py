from django.apps import AppConfig


class TvShowsConfig(AppConfig):
    name = 'tv_shows'
