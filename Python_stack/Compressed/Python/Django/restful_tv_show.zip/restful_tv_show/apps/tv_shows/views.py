from django.shortcuts import render, redirect
from .models import Show

def root(request):
    return redirect("/shows")

def index(request):
    context = {
        "all_shows" : Show.objects.all()
    }
    return render(request, "tv_shows/index.html", context)


def add_show(request):
    return render(request, "tv_shows/add_show.html")

def create_show(request):

    if request.method == "POST":
        new_show = Show.objects.create(title = request.POST['showtitle'], network = request.POST['shownetwork'], description = request.POST['desc'], release_date = request.POST['rel_date'])
        
    return redirect(f"/shows/{new_show.id}")

def show_info(request, show_id):
    context = {
        "show_info" : Show.objects.get(id=show_id)
    }
    return render(request, "tv_shows/show.html", context)

def edit_show(request, show_id):
    context = {
        "this_show" : Show.objects.get(id=show_id)
    }
    return render(request, "tv_shows/edit_show.html", context)

def update_show(request, show_id):
    if request.method == "POST":
        show_to_update = Show.objects.get(id=show_id)
        show_to_update.title = request.POST['show_title'] 
        show_to_update.network = request.POST['show_network'] 
        show_to_update.description = request.POST['descr'] 
        show_to_update.release_date = request.POST['reldate']
        show_to_update.save()

    return redirect(f"/shows/{show_id}")

def delete_show(request, show_id):
    show_to_delete = Show.objects.get(id=show_id)
    show_to_delete.delete()
    
    return redirect("/shows")

