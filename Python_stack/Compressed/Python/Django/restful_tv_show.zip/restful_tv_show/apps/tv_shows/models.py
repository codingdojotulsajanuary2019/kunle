from django.db import models

class Show(models.Model):
    title = models.CharField(max_length=255)
    network = models.CharField(max_length=255)
    description = models.TextField()
    release_date = models.DateField()
    updated_at = models.DateTimeField(auto_now=True)

    def __repr__(self):
        return f" id: {self.id}, title: {self.title}, network: {self.network}, desc: {self.description}, released: {self.release_date}, updated: {self.updated_at}"
