from django.apps import AppConfig


class BooksAppConfig(AppConfig):
    name = 'books_app'
