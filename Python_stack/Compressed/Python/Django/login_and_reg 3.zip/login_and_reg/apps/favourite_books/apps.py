from django.apps import AppConfig


class FavouriteBooksConfig(AppConfig):
    name = 'favourite_books'
