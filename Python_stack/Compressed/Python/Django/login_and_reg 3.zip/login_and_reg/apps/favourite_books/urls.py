from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^books$', views.all_books),
    url(r'^add_book$', views.add_book),
    url(r'^books/(?P<BookId>[0-9]+)$', views.view_book),
    url(r'^books/like/(?P<BookId>[0-9]+)$', views.add_fav_book),
    url(r'^books/unlike/(?P<BookId>[0-9]+)$', views.un_fav_book),
    url(r'^books/edit/(?P<BookId>[0-9]+)$', views.edit_book),
    url(r'^books/destroy/(?P<BookId>[0-9]+)$', views.delete_book),
]