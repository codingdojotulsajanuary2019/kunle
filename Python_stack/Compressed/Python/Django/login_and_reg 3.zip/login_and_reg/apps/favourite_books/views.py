from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Book

def all_books(request):

    context = {
        "all_books" : Book.objects.all().order_by('title')
    }
    return render(request, "favourite_books/index.html", context)

def add_book(request):
    if request.method == "POST":
        this_user = User.objects.get(id = request.session['user_id'])

        this_book = Book.objects.create(title = request.POST['title'], description = request.POST['desc'], uploaded_by_id = request.session['user_id'])
        
        this_book.liked_by.add(this_user)

    return redirect("/books")

def view_book(request, BookId):

    this_book = Book.objects.get(id = BookId)

    if this_book.uploaded_by_id == request.session['user_id']:
        return render(request, "favourite_books/edit_book.html", {"this_book" : this_book})

    else:
        return render(request, "favourite_books/book.html", {"this_book" : this_book})

def add_fav_book(request, BookId):
    this_user = User.objects.get(id = request.session['user_id'])
    this_book = Book.objects.get(id = BookId)

    this_book.liked_by.add(this_user)

    return redirect(f"/books/{BookId}")

def un_fav_book(request, BookId):
    this_user = User.objects.get(id = request.session['user_id'])
    this_book = Book.objects.get(id = BookId)

    this_book.liked_by.remove(this_user)

    return redirect(f"/books/{BookId}")

def edit_book(request, BookId):
    this_book = Book.objects.get(id = BookId)
    this_book.title = request.POST['title'] 
    this_book.description = request.POST['desc']
    this_book.save()

    messages.success(request, "Book successfully updated")
    return redirect(f"/books/{BookId}") 

def delete_book(request, BookId):
    this_book = Book.objects.get(id = BookId)
    this_book.delete()

    return redirect("/books")





