from django.db import models
from apps.my_users.models import User

class Book(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    uploaded_by = models.ForeignKey(User, related_name="books_uploaded")
    liked_by = models.ManyToManyField(User, related_name="books_liked")

    def __repr__(self):
        return f" title: {self.title}, desc : {self.description}, create_date: {self.created_at}, update_date: {self.updated_at}, posted_by : {self.uploaded_by}, likes: {self.liked_by}"

